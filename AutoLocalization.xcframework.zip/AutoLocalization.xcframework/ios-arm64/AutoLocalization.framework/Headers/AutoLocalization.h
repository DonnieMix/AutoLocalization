//
//  AutoLocalization.h
//  AutoLocalization
//
//  Created by Kyrylo Derkach on 29.11.2023.
//

#import <Foundation/Foundation.h>

//! Project version number for AutoLocalization.
FOUNDATION_EXPORT double AutoLocalizationVersionNumber;

//! Project version string for AutoLocalization.
FOUNDATION_EXPORT const unsigned char AutoLocalizationVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AutoLocalization/PublicHeader.h>

